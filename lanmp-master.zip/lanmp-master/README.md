# lanmp
lamp/lnmp 一键安装脚本
author: aming
version: 0.2
aaaaa
as
df
asd
f
bbbbb
